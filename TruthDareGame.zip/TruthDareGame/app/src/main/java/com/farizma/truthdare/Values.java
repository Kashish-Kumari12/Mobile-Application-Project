package com.farizma.truthdare;

public class Values {

    String[] truths = new String[]{
            "What does your dream boy or girl look like?",
            "Would you rather live with no internet or no A/C or heating?",
            "If you could go back in time in erase one thing you said or did, what would it be?",
            "Have you ever waved at someone thinking they saw you when really they didn't? What did you do when you realized it?",
            "Describe the strangest dream you've ever had. Did you like it?",
            "The world ends next week, and you can do anything you want (even if it's illegal). What would you do?",
            "How far would you go to land the guy or girl of your dreams?",
            "What is the most childish thing that you still do?"
    };

    String[] dares = new String[]{
            "Rate everyone in the room from 1 to 10, with 10 being the best personality.",
            "Go next door with a measuring cup and ask for a cup of sugar.",
            "Open Facebook, go to the account of the first person you see, and like every post on their wall going back to a year.",
            "Call your crush.", "Get into a debate with a wall.", "Eat a spoonful of mustard.",
            "Write a letter to your doctor describing an embarrassing rash you have, and post it on Facebook.",
            "Let the group choose three random things from the refrigerator and mix them together. Then you have to eat it.",
            "Dig through the trash and name everything you find.",
            "Call a NY-style pizza place and ask them what the difference is between NY pizza and “real” pizza.",
            "Take a selfie with the toilet and post it online."
    };
}
