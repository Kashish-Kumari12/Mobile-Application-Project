## **TruthDare**
A simple Truth or Dare game. Get your position around your phone and get started. If you wish you can add more truths and dares.


